%% GreyDataGeneration: demonstration of all operators
clear; clc; close all;
addpath(genpath(fileparts(fileparts(mfilename('fullpath')))));

x = [12 15 18 16 21 24]';
k = (1:numel(x))';

xAgo = gdag.ago(x);
xIago = gdag.iago(xAgo);

lambda = 0.85;
xNip = gdag.nipago(x, lambda);
xNipiago = gdag.nipiago(xNip, lambda);

r = 0.7;
xFrac = gdag.fractionalAGO(x, r);
xFracBack = gdag.fractionalIAGO(xFrac, r);

q = 3;
xDp = gdag.dpago(x, q);
xDpBack = gdag.dpiago(xDp, q);

fprintf('Maximum reconstruction errors\\n');
fprintf('1-AGO:       %.3e\\n', max(abs(x-xIago)));
fprintf('1-NIPAGO:    %.3e\\n', max(abs(x-xNipiago)));
fprintf('Fractional:  %.3e\\n', max(abs(x-xFracBack)));
fprintf('DPAGO:       %.3e\\n', max(abs(x-xDpBack)));

figure('Name','Grey data generation operators');
plot(k,x,'o-','LineWidth',1.5); hold on;
plot(k,xAgo,'s-','LineWidth',1.2);
plot(k,xNip,'d-','LineWidth',1.2);
plot(k,xFrac,'^-','LineWidth',1.2);
plot(k,xDp,'v-','LineWidth',1.2);
grid on; xlabel('Observation'); ylabel('Value');
legend('Original','1-AGO','1-NIPAGO','Fractional AGO','DPAGO', ...
    'Location','best');
title('Comparison of grey data generation operators');

[bestQ, scores] = gdag.selectLocalWindow(x, 1:numel(x));
disp(scores);
fprintf('Illustrative selected local window q = %d\\n', bestQ);
