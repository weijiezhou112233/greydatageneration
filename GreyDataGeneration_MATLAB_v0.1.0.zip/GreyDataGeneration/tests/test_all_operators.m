function tests = test_all_operators
tests = functiontests(localfunctions);
end

function testAGOInverse(testCase)
x = [2; 4; 1; 7; 3];
verifyEqual(testCase, gdag.iago(gdag.ago(x)), x, 'AbsTol', 1e-12);
end

function testNIPInverse(testCase)
x = [2; 4; 1; 7; 3];
for lambda = [0.2, 0.75, 1.0]
    verifyEqual(testCase, gdag.nipiago(gdag.nipago(x,lambda),lambda), ...
        x, 'AbsTol', 1e-12);
end
end

function testNIPLambdaOneEqualsAGO(testCase)
x = [2; 4; 1; 7; 3];
verifyEqual(testCase, gdag.nipago(x,1), gdag.ago(x), 'AbsTol', 1e-12);
end

function testFractionalInverse(testCase)
x = [2; 4; 1; 7; 3];
for r = [0.25, 0.7, 1, 1.8]
    verifyEqual(testCase, gdag.fractionalIAGO(gdag.fractionalAGO(x,r),r), ...
        x, 'AbsTol', 1e-10);
end
end

function testFractionalOrderOneEqualsAGO(testCase)
x = [2; 4; 1; 7; 3];
verifyEqual(testCase, gdag.fractionalAGO(x,1), gdag.ago(x), 'AbsTol', 1e-12);
end

function testDPAGOInverse(testCase)
x = [2; 4; 1; 7; 3; 5];
for q = 1:numel(x)
    verifyEqual(testCase, gdag.dpiago(gdag.dpago(x,q),q), ...
        x, 'AbsTol', 1e-12);
end
end

function testDPAGOWindowOne(testCase)
x = [2; 4; 1; 7];
verifyEqual(testCase, gdag.dpago(x,1), x, 'AbsTol', 1e-12);
end

function testRejectNegativeInput(testCase)
verifyError(testCase, @() gdag.ago([1 -2 3]), 'gdag:NegativeInput');
end
